package org.scrollify.enums;

public enum UserEnum {
 GUEST,
 USER,
 ADMIN  
}
