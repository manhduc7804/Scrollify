package org.scrollify.scene;

public interface Scene {
    void showScene();
}
